g = tf([5 5], [5 1 0]);
s = tf('s');
G = g * exp(-2*s);
figure;
bode(G);
