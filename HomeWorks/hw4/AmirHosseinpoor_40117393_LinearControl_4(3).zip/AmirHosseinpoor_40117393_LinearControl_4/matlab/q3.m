s = tf('s');
g = tf([5 5], [5 1 0]);
G = exp(-2*s);
final_g = g * G;
figure;
bode(g); % bedoon takhir
grid on;
title('bode figure without exp');
figure;
bode(final_g);
grid on;
title('bode figure with exp');