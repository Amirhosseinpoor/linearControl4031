
soorat = conv([1 1], conv([1 2], conv([1 3], [1,4])));
makhraj = conv([1 0 0 0 ], [1 100]);
h = tf(-1 * soorat, makhraj);
zpk(h)
figure;
nyquist(h)