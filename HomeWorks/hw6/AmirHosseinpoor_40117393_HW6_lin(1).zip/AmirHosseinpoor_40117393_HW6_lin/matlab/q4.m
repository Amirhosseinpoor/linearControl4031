
G = tf(3750,[1,25,0]);
C = tf([0.021,1], [0.007, 1]);
G1 = minreal(C*G);
figure(1)
margin(G1)
figure(2)
hold on
step(minreal(G1/(1+G1)))
step(tf(1))
legend('Step response of system', 'Step')
figure(3)
hold on
step(minreal(tf(1,[1,0])*G1/((1+G1))))
step(tf(1,[1,0]))
title('Ramp Response')
legend('Ramp response of system', 'Ramp')