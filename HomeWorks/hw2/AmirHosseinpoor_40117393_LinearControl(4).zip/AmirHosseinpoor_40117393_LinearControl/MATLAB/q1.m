k = 1.58;
wn = 11.306;
xi = 0.2509;

numerator = k * wn^2;
denominator = [1, 2*xi*wn, wn^2];
closed_loop_system = tf(numerator, denominator);

figure;
[response, time] = step(closed_loop_system);
plot(time, response);
title('Step Response of Closed-Loop System');
xlabel('Time');
ylabel('Amplitude');
grid on;

info = stepinfo(closed_loop_system);
disp(info);

hold on;
peak_time = info.PeakTime;
peak_value = info.Peak;
final_value = response(end);
overshoot_percent = info.Overshoot;

plot(peak_time, peak_value, 'ro', 'MarkerFaceColor', 'r');
text(peak_time, peak_value, sprintf('Peak: %.2f\nOvershoot: %.1f%%\nTime: %.2f sec', peak_value, overshoot_percent, peak_time), ...
    'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
yline(final_value, '--', sprintf('Final Value: %.2f', final_value));

open_loop_system = closed_loop_system / (1 - closed_loop_system);

figure;
step(open_loop_system);
title('Step Response of Open-Loop System');
xlabel('Time (seconds)');
ylabel('Amplitude');
grid on;
