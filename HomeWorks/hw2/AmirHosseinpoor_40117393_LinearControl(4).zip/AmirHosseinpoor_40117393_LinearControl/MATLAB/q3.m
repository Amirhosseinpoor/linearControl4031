
K = 8.41;
T = tf(K, [1 4 K]);

figure;
step(T);
title('Step Response of the System for K = 8.41');
xlabel('Time');
ylabel('Amplitude');
grid on;

info = stepinfo(T);
disp(info);
