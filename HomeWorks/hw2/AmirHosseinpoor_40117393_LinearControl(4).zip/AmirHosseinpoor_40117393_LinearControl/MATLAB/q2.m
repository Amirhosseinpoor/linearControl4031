G_open = tf(0.4, [1 0.4]);
T_closed = tf(0.4, [1 0.8]);

figure;
[response_open, time_open] = step(G_open);
[response_closed, time_closed] = step(T_closed);
plot(time_open, response_open, 'b', 'LineWidth', 1.5);
hold on;
plot(time_closed, response_closed, 'r', 'LineWidth', 1.5);
title('Step Response of Open-Loop and Closed-Loop Systems');
xlabel('Time (seconds)');
ylabel('Amplitude');
legend('Open-Loop', 'Closed-Loop');
grid on;

info_open = stepinfo(G_open);
info_closed = stepinfo(T_closed);

steady_state_open = response_open(end);
steady_state_closed = response_closed(end);
steady_state_error_open = abs(1 - steady_state_open);
steady_state_error_closed = abs(0.5 - steady_state_closed);

time_constant_open = 1 / 0.4;
time_constant_closed = 1 / 0.8;

disp('Open-Loop System Characteristics:');
disp(['  Rise Time: ' num2str(info_open.RiseTime)]);
disp(['  Settling Time: ' num2str(info_open.SettlingTime)]);
disp(['  Overshoot: ' num2str(info_open.Overshoot) '%']);
disp(['  Steady-State Value: ' num2str(steady_state_open)]);
disp(['  Steady-State Error: ' num2str(steady_state_error_open)]);
disp(['  Time Constant: ' num2str(time_constant_open) ' sec']);

disp('Closed-Loop System Characteristics:');
disp(['  Rise Time: ' num2str(info_closed.RiseTime)]);
disp(['  Settling Time: ' num2str(info_closed.SettlingTime)]);
disp(['  Overshoot: ' num2str(info_closed.Overshoot) '%']);
disp(['  Steady-State Value: ' num2str(steady_state_closed)]);
disp(['  Steady-State Error: ' num2str(steady_state_error_closed)]);
disp(['  Time Constant: ' num2str(time_constant_closed) ' sec']);

text(6, 0.85, sprintf('Open-Loop:\nRise Time: %.2f sec\nSettling Time: %.2f sec\nOvershoot: %.1f%%\nSteady-State Error: %.2f\nTime Constant: %.2f sec', ...
    info_open.RiseTime, info_open.SettlingTime, info_open.Overshoot, steady_state_error_open, time_constant_open), ...
    'VerticalAlignment', 'top', 'HorizontalAlignment', 'left', 'Color', 'blue', 'FontSize', 10);

text(6, 0.2, sprintf('Closed-Loop:\nRise Time: %.2f sec\nSettling Time: %.2f sec\nOvershoot: %.1f%%\nSteady-State Error: %.2f\nTime Constant: %.2f sec', ...
    info_closed.RiseTime, info_closed.SettlingTime, info_closed.Overshoot, steady_state_error_closed, time_constant_closed), ...
    'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left', 'Color', 'red', 'FontSize', 10);

hold off;
