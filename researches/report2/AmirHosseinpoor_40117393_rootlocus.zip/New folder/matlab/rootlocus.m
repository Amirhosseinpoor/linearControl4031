	s = tf('s');
	G_no_delay = 1 / (s^2 + 3*s + 2);
	figure;
	rlocus(G_no_delay);
	title('Root Locus of System Without Delay');
	delay = 2; % Time delay
	[num, den] = pade(delay, 1); % First-order Pade approximation
	Pade_approx = tf(num, den);
	G_with_delay = Pade_approx / (s^2 + 3*s + 2);
	figure;
	rlocus(G_with_delay);
	title('Root Locus of System with Delay (Pade Approximation)');