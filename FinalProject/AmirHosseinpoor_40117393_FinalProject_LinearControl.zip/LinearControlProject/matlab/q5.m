num = [0.1 -0.2];  
den = [1 0.9 9 0];  
figure;  
g=tf(num,den);
rlocus(tf(num, den));  
title('Root Locus of G(s)');  



