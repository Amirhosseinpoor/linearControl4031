	s = tf('s');
	
	P = tf([0.1 -0.2],[1 0.9 9 0]);
	
	Td = tf([1 -2],[1 3 3 1]);
	Td = Td * -0.5;
	
	Sd = 1 - Td;
	
	C = Td/(Sd * P);
	
	L = C * P;
	
	close_loop = feedback(L, 1);
	figure;
	step(close_loop);
	grid on;
	figure;
	bode(L);
	grid on;
	
	t = 0:0.01:10; 
	u = t;  
	
	figure;
	lsim(close_loop, u, t);
	grid on;
	xlabel('Time (sec)');
	ylabel('Response');
	title('Ramp Response of the System');

    lag_controller = 1 + (100/(1373*s+1));
    k = 2.5;

    final_L = k * lag_controller * L;

    disp(dcgain(final_L*s));
    close_loop_with_controller = feedback(final_L, 1);
    figure;
    lsim(close_loop_with_controller, u, t);
    grid on;
    title('ramp response of final closed loop');


