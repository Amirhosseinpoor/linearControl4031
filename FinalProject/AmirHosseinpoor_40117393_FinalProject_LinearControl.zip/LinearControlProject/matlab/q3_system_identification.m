data = load('Data.mat');
responseData = data.Data;

omega = responseData.omega;
magnitude = responseData.magnitude;
phase = responseData.phase;

phase = deg2rad(phase);
frequencyResponse = magnitude .* exp(1i * phase);
frdData = frd(frequencyResponse, omega, 'FrequencyUnit', 'rad/s');

systemIdentification
