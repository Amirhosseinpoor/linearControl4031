figure;
bode(tf1);
grid on;
title('Bode Plot of Identified Transfer Function');
