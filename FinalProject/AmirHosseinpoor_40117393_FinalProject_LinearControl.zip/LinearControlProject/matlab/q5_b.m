
num = [0.1 -0.2];  
den = [1 0.9 9 0];  
G = tf(num, den); 


Kp = 10; 
Kd = 2;  

C = tf([Kd Kp], [1]); 

sys_cl = feedback(C * G, 1);

figure;
rlocus(C * G);
title('Root Locus with PD Controller');

sisotool(G)

