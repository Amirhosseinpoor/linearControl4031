	s = tf('s');
	
	P = tf([0.1 -0.2],[1 0.9 9 0]);
	
	Td = tf([1 -2],[1 3 3 1]);
	Td = Td * -0.5;
	
	Sd = 1 - Td;
	
	C = Td/(Sd * P);
	
	L = C * P;
	
	close_loop = feedback(L, 1);
	figure;
	step(close_loop);
    title('step response of close loop');
	grid on;
    info = stepinfo(close_loop);
    undershoot = info.Undershoot;
    settling_time = info.SettlingTime;
    disp(['Undershoot: ', num2str(undershoot), '%']);
    disp(['Settling Time: ', num2str(settling_time), ' sec']);


    close_loop2 = feedback(1.15*L, 1);
	figure;
	step(close_loop2);
    title('step response of close loop with gain');
	grid on;
    info = stepinfo(close_loop2);
    undershoot = info.Undershoot;
    settling_time = info.SettlingTime;
    disp(['Undershoot: ', num2str(undershoot), '%']);
    disp(['Settling Time: ', num2str(settling_time), ' sec']);
    
