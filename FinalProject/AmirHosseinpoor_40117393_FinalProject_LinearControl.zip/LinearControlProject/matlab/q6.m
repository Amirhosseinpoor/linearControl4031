    
    num1 = [1.6233 1]; %lag 
    den1 = [3 1];  
    
    num2 = [0.3714 1]; %lead
    den2 = [0.1726 1]; 
    
    num3 = [9*1.7/sqrt(3.8452)];       
    den3 = [1 0.9 9];   
    

    G1 = tf(num1, den1);
    G2 = tf(num2, den2);
    G3 = tf(num3, den3);
    
    G_new = G3 *G2 *G1;
    
    figure;
    bode(G_new);
    title('Bode Figuration of the Final System');
    grid on;
    hold on;
    
    figure;
    [y, t] = step(G_new);
    stepinfo_data = stepinfo(G_new);
    
    plot(t, y, 'b', 'LineWidth', 1.5);
    xlabel('Time (sec)');
    ylabel('Response');
    title('Step Response of the Final System');
    grid on;
    
    disp(['Overshoot (%): ', num2str(stepinfo_data.Overshoot)]);
    disp(['Settling Time (sec): ', num2str(stepinfo_data.SettlingTime)]);
    
    num = [0.1];       
    den = [1 0.9 9]; 

    G_original = tf([num], [den]);
    figure;
    bode(G_original);
    title('Bode Figuration of the Original System');
    grid on;
    hold on;

    figure;
    [y1, t1] = step(G_original);
    stepinfo_data1 = stepinfo(G_original);
    
    plot(t1, y1, 'b', 'LineWidth', 1.5);
    xlabel('Time (sec)');
    ylabel('Response');
    title('Step Response of the Original System');
    grid on;
    
    disp(['Overshoot (%): ', num2str(stepinfo_data1.Overshoot)]);
    disp(['Settling Time (sec): ', num2str(stepinfo_data1.SettlingTime)]);

